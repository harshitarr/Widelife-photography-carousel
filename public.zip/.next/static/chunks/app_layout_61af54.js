(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_61af54.js",
  "chunks": [
    "static/chunks/[root of the server]__501b62._.css",
    "static/chunks/app_layout_d9f7ea.js"
  ],
  "source": "dynamic"
});
